import sys
import math
import random
surv=[[] for i in range(10)]
def survey():
	for i in range(11):
		name = input('What is your name?: ')
		surv[i].append(name)
		food =input('What is your favorite food?: ')
		surv[i].append(food)
		sport =input('What is your fall sport?: ')
		surv[i].append(sport)
		class1 =input('What is your favorite class?: ')
		surv[i].append(class1)
		movie =input('What is your favorite movie?: ')
		surv[i].append(movie)
		foodp =input('What is your favorite fast food place?: ')
		surv[i].append(foodp)
	print(surv)
survey()
