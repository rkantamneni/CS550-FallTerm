import sys
import math

x = input ('Type an x value: ')
y = input ('Type an y value: ')
z = input ('Type an z value: ')

if x<y and y<z:
	print('True')
else:
	print('False')