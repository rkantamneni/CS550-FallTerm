import sys


def num(n):
  if n == 0:
    return 0
  else:
    return (n%10) + num(n//10)
    
print(num(int(input("Enter number: "))))

def clean(string):
    if len(string) == 1:
        return string
    if string[0] == string[1]:
        return clean(string[1:])
    return string[0] + clean(string[1:])

print(clean("zzdffjkki"))

