'''
Generate a list of 10 random numbers between 0 and 100. Get them in order from largest to smallest, removing numbers divisible by 3. (Ms. Healey)
Generate a list of 100 numbers, 1 to 100, without using a loop. Shuffle the list up so the numbers are not in order. (Ms. Healey)
Create a list from 0 to 100, and rearrange them until the list has no numbers that are adjacent in integer order next to each other in the list. For example, [1, 2, 3, 4] could be [3, 1, 4, 2] (John, Jack, Henry)
'''
import random
import sys
import math
from random import *
from random import shuffle

x=[randint(0,100) for i in range(10)]
print(x)
def order(my_list):
    size = len(my_list)
    for i in range(size):
        for j in range(size-i-1):
            if(my_list[j] > my_list[j+1]):
                num = my_list[j]
                my_list[j] = my_list[j+1]
                my_list[j+1] = num
       		#my_list.remove(y)
    mult3 = [ x for x in my_list if x%3 != 0 ]
    print(mult3)
order(x)
'''

'''
list2=list(range(100))
#shuffle(list2)
import random

def list_randomizer(lst):
    result = []
    while len(lst) > 0:
        index = random.randrange(0,len(lst))
        result.append(lst.pop(index))
    return result
    print (result)
list_randomizer(list2)

#def shufflelist1):
 #   array_len = len(list1)
  #  for index in range(array_len):
   #     swap = random.randrange(array_len - 1)
    #    swap += swap >= index
     #   list1[index], list1[swap] = array[swap], array[index]

f=[randint(0,100) for i in range(10)]
print(f)
newe=[]
newo=[]

newo = [ x for x in f if x%2 == 1 ]
newe = [ x for x in f if x%2 == 0 ]
newo.sort(reverse=False)
newe.sort()
newe.reverse()
print(newo)
print(newe)




