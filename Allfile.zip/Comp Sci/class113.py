#Account
'''
balance number
interest rate
pin
account
'''
class account:
	def __init__(self, time):
		self.amount=100
		self.interest=0.02
		self.pin=1234
		self.accountnum=1010
		self.deposit=deposit
		self.withdraw=withdraw
		self.time=time
		self.unlock=False
	def lock(self, accountnum, pin):
		if self.pin==1234 and self.accountnum==1010:
			
	def start(self, amount):
		print("You have $"+self.amount)
		self.amount=(self.amount*(1+self.interest)**self.time)
		print("In "+time+" months, you will have $"+amount)
	def deposit(self, deposit, amount):
		self.amount+=self.deposit
	def withdraw(self, withdraw, account)
		self.amount-=self.deposit

bank = account()