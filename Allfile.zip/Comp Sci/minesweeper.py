import sys
import random
import random

#create empty board
#place bombs
#place numbers
# display nicely

a=[]
r=int(sys.argv[1])+1
c=int(sys.argv[2])+1
b=int(sys.argv[3])
x=('You have '+sys.argv[1]+" rows")
y=('You have '+sys.argv[2]+" columns")
bombprin=('You have '+sys.argv[3]+" bombs")


#board
for x in range(r+1):
        a.append([])
        for y in range(c+1):
            a[x].append("*")

#input bombs
t=0
while t<b:
	s=random.randint(0,r-1)
	d=random.randint(0,c-1)
	if a[s][d] != "B":
		a[s][d]="B"
		t+=1

#checking
for i in range(r):
	for j in range(c):
		if a[i][j]=="B":
			pass
		else:
			count=0
			if a[i-1][j-1]=="B":
				count+=1
			if a[i-1][j]=="B":
				count+=1
			if a[i][j-1]=="B":
				count+=1
			if a[i+1][j+1]=="B":
				count+=1
			if a[i+1][j]=="B":
				count+=1
			if a[i][j+1]=="B":
				count+=1
			if a[i+1][j-1]=="B":
				count+=1
			if a[i-1][j+1]=="B":
				count+=1
			a[i][j]=count


#format board
for i in range(r):
	for j in range(c):
		print(a[i][j],end=' ')
		
	print()






