import sys
def brot(x, y):
	s1 = sqrt((x*x)-(y*y))
	s2 = 2*x*y
	s3=((s1*x)+()
	