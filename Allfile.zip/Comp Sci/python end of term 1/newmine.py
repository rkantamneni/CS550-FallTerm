
#Minesweeper
#Terminal Version

from random import randint
import tkinter
from tkinter import *
import os

board= []
mines=[]
board_row = 0
adj = 0
wrong= 0
replay= " "

def intro():
	while True:
		#print('Welcome to Minesweeper!')
		board_row = int(input("How many rows would you like?: "))
		if board_row > 10:
			print("Too big")
		elif board_row<5:
			print("Too small")
		else:
			break

	if board_row > 8:
		for i in range(15):
			mines.append([randint(0, board_row-1), randint(0, board_row-1)])
	elif board_row > 5:
		for i in range(5):
			mines.append([randint(0, board_row-1), randint(0, board_row-1)])

	for i in range(board_row):
		board.append(["X"]*board_row)


def draw_board(board):
  	for i in board:
  		print(" ".join(i))

def check_ans():
	if row>=board_row or col>=board_row:
		print("Too high", board_row-1)
		wrong=1
	else:
		wrong=0

  
def adj_mines(r, c, adj):
	adj=0
	if [r+1, c] in mines:
		adj+=1
	if [r+1, c+1] in mines:
		adj+=1
	if [r, c+1] in mines:
		adj+=1
	if [r-1, c+1] in mines:
		adj+=1
	if [r-1, c] in mines:
		adj+=1
	if [r-1, c-1] in mines:
		adj+=1
	if [r, c-1] in mines:
		adj+=1
	if [r+1, c-1] in mines:
		adj+=1
	return adj

def game_over():
    print('Opps... Game over!')
    replay = input('Type Y to play again. Type anything else to exit')
    if replay=="y" or replay=='Y':
    	play()
    else:
    	exit()


#Getting this function to work took 2.5 hours
def surround(r, c):
	if board[r][c]== "0":

		if r < board_row-1 and board[r+1][c]=="X":
			board[r+1][c] = str(adj_mines(r+1, c, 0))
			#if str(adj_mines(row+1, col, 0)) == "0":
			surround(r+1, c)

		if r < board_row-1 and c < board_row-1 and board[r+1][c+1]=="X":
			board[r+1][c+1] = str(adj_mines(r+1, c+1, 0))
			surround(r+1, c+1)

		if c < board_row-1 and board[r][c+1]=="X":
			board[r][c+1] = str(adj_mines(r, c+1, 0))
			#if str(adj_mines(row, col+1, 0)) == "0":
			surround(r, c+1)

		if r > 0 and c < board_row-1 and board[r-1][c+1]=="X":
			board[r-1][c+1] = str(adj_mines(r-1, c+1, 0))
			#if str(adj_mines(row-1, col+1, 0)) == "0":
			surround(r-1, c+1)
				

		if r > 0 and board[r-1][c]=="X":
			board[r-1][c] = str(adj_mines(r-1, c, 0))
			#if str(adj_mines(row-1, col, 0)) == "0":
			surround(r-1, c)
				

		if r > 0 and c > 0 and board[row-1][c-1]=="X":
			board[r-1][c-1] = str(adj_mines(r-1, c-1, 0))
			#if str(adj_mines(row-1, col-1, 0)) == "0":
			surround(r-1, c-1)
				

		if c > 0 and board[r][c-1]=="X":
			board[row][c-1] = str(adj_mines(r, c-1, 0))
			#if str(adj_mines(row, col-1, 0)) == "0":
			surround(r, c-1)


		if r < board_row-1 and c > 0 and board[r+1][c-1]=="X": 
			board[r+1][c-1] = str(adj_mines(r+1, c-1, 0))
			#if str(adj_mines(row+1, col-1, 0)) == "0":
			surround(r+1, c-1)
	'''
		board[row][col+1] = str(adj_mines(row, col+1, 0))
		board[row-1][col+1] = str(adj_mines(row-1, col+1, 0))
		board[row-1][col] = str(adj_mines(row-1, col, 0))
		board[row-1][col-1] = str(adj_mines(row-1, col-1, 0))
		board[row][col-1] = str(adj_mines(row, col-1, 0))
		board[row+1][col-1] = str(adj_mines(row+1, col-1, 0))

'''



	'''
		board[row+1][col] = str(adj_mines(row+1, col, 0))
		board[row+1][col+1] = str(adj_mines(row+1, col+1, 0))
		board[row][col+1] = str(adj_mines(row, col+1, 0))
		board[row-1][col+1] = str(adj_mines(row-1, col+1, 0))
		board[row-1][col] = str(adj_mines(row-1, col, 0))
		board[row-1][col-1] = str(adj_mines(row-1, col-1, 0))
		board[row][col-1] = str(adj_mines(row, col-1, 0))
		board[row+1][col-1] = str(adj_mines(row+1, col-1, 0))
		'''

#Attempted to use recursion but didn't work out. Even if it did, the game would take a lot less time and be less fun.
def play():	
	intro()
	draw_board(board)
	while True:
		global row
		global col
		row = int(input("Row: "))-1
		col = int(input("Column: "))-1
		check_ans()
		if wrong != 1:
			if [row, col] in mines:
				break
			else:
				board[row][col] = str(adj_mines(row, col, 0))
				surround(row, col)
			print(chr(27) + "[2J") # system.os('clear') isn't working
			draw_board(board)
	game_over()

play()

