import tkinter as tk

root = tk.Tk()
tk.Label(root, text="this is the root window").pack()
root.geometry("200x200")
for i in range(4):
    window = tk.Toplevel()
    window.geometry("200x200")

    tk.Label(window, text="this is window %s" % i).pack()

root.mainloop()


# execute the mandelbrot calculation
			r = mandelbrot(z, c, 0)/255
			newr = colorsys.hsv_to_rgb(r, 1.0, 1.0)

			# use the mandelbrot result to create a color
			rd = hex((newr[0]*255%(rd1))*rd2)[2:].zfill(2)
			gr = hex((newr[1]%(gr1))*gr2)[2:].zfill(2)
			bl = hex((r%(bl1))*bl2)[2:].zfill(2)

			if win==1:
				img1.put("#" + rd + gr + bl, (col, row))
			if win==2:
				img2.put("#" + rd + gr + bl, (col, row))
			if win==3:
				img3.put("#" + rd + gr + bl, (col, row))