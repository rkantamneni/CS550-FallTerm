# mine-sweeper
Mine sweeper game in Python

### getting started
```bash

python3 mine_sweeper.py

```

https://medium.com/@stephenslee0127/mine-sweeper-game-in-python-23dba63a049
