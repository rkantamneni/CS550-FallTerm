# Original code from:
# http://code.activestate.com/recipes/578590-mandelbrot-fractal-using-tkinter/

# import the libraries you'll need
import tkinter
from tkinter import *
import math
import colorsys


# recursive mandelbrot function gives us the number of iterations to escape
def mandelbrot(z, c, count):
	z = (z**2)+c
	count+=1
	if abs(z)>2 or count>maxIt-1:
		return count
	return mandelbrot(z, c, count)
	# the calculations that follow are how you would do it 
	# if you didn't use complex numbers in python;
	# like we did on your worksheet.

	# calculate z squared
	# temp = zx*zx - zy*zy
	# zy = 2*zx*zy
	# zx = temp

	# calculate z squared plus c to get our new z value
	# zy = zy + cy
	# zx = zx + cx

	# update iteration counter
	# count = count + 1

	# if we escape or we hit the max number of iterations
	# stop executing and return the number of iterations
	# if count >= maxIt or zx*zx + zy*zy >= 4:
	# 	return count
	

	# otherwise, since we didn't escape or hit the max iterations,
	# calculate a new z again (call mandelbrot function again)
	# return mandelbrot(zx, zy, cx, cy, count)


# variables we will use throughout the program
WIDTH = 640 # width and height of our picture in pixels
HEIGHT = 480
xmin = -0.7633854 # the zoom we want to see 
xmax = -0.761927083
ymin = 0.088593750
ymax = 0.0900520833
maxIt = 256 # max iterations; corresponds to color

# create a new Tkinter window
window = Tk()

# create a canvas, and place it in the window
canvas = Canvas(window, width = WIDTH, height = HEIGHT, bg = "#000000")#background color

# set up the canvas so it can hold a picture
img = PhotoImage(width = WIDTH, height = HEIGHT)
canvas.create_image((0, 0), image = img, state = "normal", anchor = tkinter.NW)

# loop through all the pixels in the image
for row in range(HEIGHT):
    for col in range(WIDTH):
    	# calculate C for each pixel
        c = complex((((xmax-xmin)*col)/WIDTH)+xmin, (((ymax-ymin)*row)/HEIGHT)+ymin) #
        # set z to 0
        z = complex(0.0, 0.0)

        # execute the mandelbrot calculation
        r = mandelbrot(z, c, 0)
        
        # use the mandelbrot result to create a color
        rd = hex(r % 4 * 64)[2:].zfill(2)
        gr = hex(r % 8 * 32)[2:].zfill(2)
        bl = hex(r % 16 * 16)[2:].zfill(2)

        # update the pixel at the current position to hold
        # the color we created with the mandelbrot result
        img.put("#" + rd + gr + bl, (col, row))

# update the canvas and display our drawing
canvas.pack()
mainloop()


