# import the libraries you'll need
import tkinter
from tkinter import *
import math
import colorsys
maxIt = 256 # max iterations; corresponds to color

def mandelbrot(z, c, count):
	z = (z**2)+c
	count+=1
	if abs(z)>2 or count>maxIt-1:
		return count
	return mandelbrot(z, c, count)

# variables we will use throughout the program
# create a new Tkinter window
def threeman(xmin, xmax, ymin, ymax, rd1, rd2, gr1, gr2, bl1, bl2, win):
	WIDTH = 320 # width and height of our picture in pixels
	HEIGHT = 240
	
	if win==1:
		window1 = Tk()
		canvas1 = Canvas(window1, width = WIDTH, height = HEIGHT, bg = "#000000")#background color
		img1 = PhotoImage(width = WIDTH, height = HEIGHT)
		canvas1.create_image((0, 0), image = img1, state = "normal", anchor = tkinter.NW)
	elif win==2:
		window2 = Toplevel()
		canvas2 = Canvas(window2, width = WIDTH, height = HEIGHT, bg = "#000000")#background color
		img2 = PhotoImage(width = WIDTH, height = HEIGHT)
		canvas2.create_image((0, 0), image = img2, state = "normal", anchor = tkinter.NW)
	elif win==3:
		window3 =Toplevel()
		canvas3 = Canvas(window3, width = WIDTH, height = HEIGHT, bg = "#000000")#background color
		img3 = PhotoImage(width = WIDTH, height = HEIGHT)
		canvas3.create_image((0, 0), image = img3, state = "normal", anchor = tkinter.NW)

	# loop through all the pixels in the image
	for row in range(HEIGHT):
		for col in range(WIDTH):
			# calculate C for each pixel
			c = complex((((xmax-xmin)*col)/WIDTH)+xmin, (((ymax-ymin)*row)/HEIGHT)+ymin) #
			# set z to 0
			z = complex(0.0, 0.0)

			# execute the mandelbrot calculation
			r = mandelbrot(z, c, 0)

			# use the mandelbrot result to create a color
			rd = hex((r%(rd1))*rd2)[2:].zfill(2)
			gr = hex((r%(gr1))*gr2)[2:].zfill(2)
			bl = hex((r%(bl1))*bl2)[2:].zfill(2)

			if win==1:
				img1.put("#" + rd + gr + bl, (col, row))
			if win==2:
				img2.put("#" + rd + gr + bl, (col, row))
			if win==3:
				img3.put("#" + rd + gr + bl, (col, row))
	if win==1:
		canvas1.pack()
	elif win==2:
		canvas2.pack()
	elif win==3:
		canvas3.pack()

threeman(-0.7633854,-0.761927083, 0.088593750, 0.0900520833, 10, 10, 15, 17, 10, 10, 1)
threeman(-2,2, 0.088593750, 0.0900520833, 10, 10, 15, 17, 10, 10, 2)
threeman(-2,2, 0.088593750, 0.0900520833, 10, 10, 15, 17, 10, 10, 2)
mainloop()


