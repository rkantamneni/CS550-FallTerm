import sys
import random

# print the 2D array nicely like a game board
def printNice(twodee):
	for row in range(1, len(twodee)-1):
		for col in range(1, len(twodee[0])-1):
			print(twodee[row][col], end=' ')
		print('')

width = int(sys.argv[2])+2
height = int(sys.argv[1])+2
mines = int(sys.argv[3])

# create an empty board
board = []
for i in range(height):
	row = ['.']*width
	board.append(row)

# add mines to the board
for i in range(mines):
	x = random.randint(1,height-2)
	y = random.randint(1,width-2)
	while board[x][y] == '*':
		x = random.randint(1,height-2)
		y = random.randint(1,width-2)
	board[x][y] = '*'

# calculate neighbors
for r in range(1, len(board)-1):
	for c in range(1, len(board[0])-1):
		if board[r][c] != '*':
			neighbors = 0
			if board[r][c-1] == '*':
				neighbors += 1
			if board[r][c+1] == '*':
				neighbors += 1
			if board[r-1][c] == '*':
				neighbors += 1
			if board[r+1][c] == '*':
				neighbors += 1
			if board[r-1][c-1] == '*':
				neighbors += 1
			if board[r+1][c-1] == '*':
				neighbors += 1
			if board[r-1][c+1] == '*':
				neighbors += 1
			if board[r+1][c+1] == '*':
				neighbors += 1
			if neighbors > 0:
				board[r][c] = neighbors

# print the completed board using my helper function		
printNice(board)