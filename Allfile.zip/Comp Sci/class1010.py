import sys
import random
from random import *
'''
empty = []
empty1 = [1,2,3,4,5,6]
empty1.insert(0,0)
print(empty1)
empty1.remove(0)
print(empty1)
empty1.remove(3)
print(empty1)
empty1.remove(6)
print(empty1)
print(empty1[3])
empty1[2]=2.5
print(empty1)
print(len(empty1))
empty1[0]=2
empty1[1]=1
print(empty1)

list1=[7,14,21,28,35,42,49,56,63,70,77,84,91,98]
print(random.choice(list1))
'''
list100=[]
for x in range(0, 10):
	list100.append(randint(0, 100))
	print((list100))
list100.sort()
print(list100)

#list200 = [randint(0,100) for i in range(10)]
#print (list200)

def order(my_list):
    size = len(my_list)
    for i in range(size):
        for j in range(size-i-1):
            if(my_list[j] > my_list[j+1]):
                num = my_list[j]
                my_list[j] = my_list[j+1]
                my_list[j+1] = num
    print my_list
    












