Minesweeper
===========
A very simple minesweeper game implemented with python + Tkinter. Just one of my practices with basic python GUI programming.

Contents:
-----------
- /minesweeper.py - the actual python code that does the work
- /images - image files used by the GUI

Reference:
-----------
The skeleton of the code is extracted from [ripexz's implementation][1]. Many thanks, ripexz!
[1]: https://github.com/ripexz/python-tkinter-minesweeper
